def recurse(n, i):
## Your code - begin
  if(i<=len(n)//2):    #half the length to check the string
    if(n[i]==n[len(n)-i-1]):  #checking the 1st and last,2nd and 2nd last elements.so on
      return recurse(n,i+1)   #if the element matches,return the function with new index 
    else:
      return False            #if not, means the string is not palindrome
  else:
    return True               #if the length/2 of string is checked, means the string is    
## Your code - end            #palindrome and therefore return True

def isPalindrome(n):
  return recurse(n, 0)
  
if __name__ == '__main__':
	n = raw_input("Enter string: ")
	output = isPalindrome(n)     #calling of function
	print output
