def factorial(n):
## Your code - begin
  if(n>1):            
    return n * factorial(n-1)   #factorial of n = n*(n-1)*(n-2)*.....1
  else:
    return 1          #return 1 as factorial of 1 is '1'
## Your code - end

if __name__ == "__main__":
	n = input("Enter number: ")  
	output = factorial(n)  #calling define function
	print output
