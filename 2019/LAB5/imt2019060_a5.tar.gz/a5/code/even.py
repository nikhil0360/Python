def even_elements(l):
## Your code - begin
  even_l = [ i for i in l if i%2==0] # using list comprehension to make new list which  
  return even_l                      # has even elements 
## Your code - end
  
if __name__ == "__main__":
  l = range(10)            
  print "input = ", l                
  print even_elements(l)             #calling the defined function 
