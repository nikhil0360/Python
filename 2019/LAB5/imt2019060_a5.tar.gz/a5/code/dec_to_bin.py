def recurse(ans, n):
## Your code - begin
  if(n!=0):              #if n is not '0' 
    if(n%2==0):
      return recurse('0'+ans,n//2)   # if remainder(n,2) is '0' , than add 0 to string
    else:
      return recurse('1'+ans,n//2)   # if remainder(n,2) is '1' , than add 1 to string
  else:
    return ans           #if n is '0', means the process is done... then return the string
   
## Your code - end

def decToBin(n):        # function declaration 
  return recurse("",n) 

if __name__ == "__main__":
  n = input("Enter number: ")
  output = decToBin(n)   # calling made function 
  print output
