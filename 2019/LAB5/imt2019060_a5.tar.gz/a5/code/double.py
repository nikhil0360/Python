def double(l):
## Your code - begin
  dl = [ 2*i for i in l]  # using list comprehension to increase element in list l 
  return dl               # two times and return the new list 
## Your code - end
  
if __name__ == "__main__":
  l = [1, 2, 3]
  print "input = ", l
  print double([1, 2, 3])
