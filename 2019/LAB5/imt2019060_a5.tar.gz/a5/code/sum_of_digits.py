def sumDigits(n):
## Your code - begin

  new_n = n//10
  if(new_n!=0): 
    r_n = n%10       #remainder ---> individual number to be added
    return r_n + sumDigits(new_n)  #---> add the value and call function for the next number
  else:
    r_n = n%10
    return r_n
## Your code - end

if __name__ == "__main__":
	n = input("Enter number: ")
	output = sumDigits(n)     #calling the defined function
	print output
