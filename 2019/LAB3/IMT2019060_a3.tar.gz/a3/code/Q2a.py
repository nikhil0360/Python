from Q2input import *

# Your code - begin
output={} 

#Dic1 , Dic2   here taking Dic1 as the base

for i in Dic2:        #iterating keys of Dic2 in 'i'
  if( i in Dic1 ):      #if key 'i' is in Dic1
    Dic1[i] += Dic2[i]    #increase the key 'i' value in Dic1 by adding value of Dic2 
  else:                 #else
    Dic1[i] = Dic2[i]     #create a key 'i' in Dic1 with value Dic2

output = Dic1         #setting output to Dic1 as it was our base
# Your code - end
print output
