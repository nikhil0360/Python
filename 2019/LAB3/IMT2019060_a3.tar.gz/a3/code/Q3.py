from Q3input import *

# Your code - begin
output = ""    
l = []              #creating a blank list
for i in inp:       #take character from inp and appending it to list 'l'
  if(i!=" "):       #if char is not blank
    l.append(i)     #append


for n in l:         #taking values of list 'l' in 'n'
  count = 0         #setting a counter to check
  for m in l:       #again taking values of list 'l' in 'm'
    if(n==m):        #comparing 'n' and 'm' 
      count += 1     #increasing count by 1 if n==m
  if(count!=1):      #now if count is greater than 1, it means the char has repeated
    print(False)       #if char is repeated , print False and End the program
    break
else:
 print(True)         #else loops excecute without any break, print True(that means every char is unique) 

# Your code - end
print output
