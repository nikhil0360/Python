from Q6input import *

# Your code - begin

output = ''                 
l1 = []                  #creating a blank list for proceesing 
for m in range(100):     #list contain many blank list
  l1.append([])
                             
for i in inp:            # character 'i' in inp 
  c1 = 0                 
  for j in inp:          # again character 'j' in inp 
    if(i==j):              #comparing 'i' and 'j'
      c1 += 1                #increase c1 by 1
  if(i not in l1[c1]):     #add 'i' if it's not already in the list of frequence list (list[c1])
    l1[c1].append(i)      
#print(l1)
       
for n in range(len(l1)):   #this block of code just compare the character with one another
  while(len(l1[n])>1):     #until only 1 character is left in all inside list with lowest ascii value
    if(l1[n][0]>l1[n][len(l1[n][1])]):
      l1[n].pop(0)
    else:
      l1[n].pop(1)

c2 = 0                     #caluclate number of blank list in bigger list 
for p in l1:
  if(p==[]):
    c2 += 1
  
for q in range(c2):        #removing the blank list in Bigger list 
    l1.remove([])

#print(l1)
output = l1[len(l1)-N][0]  #storing the value of the Nth most frequent charcter in Output
  

# Your code - end
print output
