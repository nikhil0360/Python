from Q4input import *

# Your code - begin
output = [] #this code was easy 
a = 0       #a is used to count 
for i in range(len(inp)):     
  if(inp[i]==0):
    a +=1                 # counting number of a

inp = [ x for x in inp if(x!=0) ] #creating new list without zero

for i in range(a):    # adding 'a' zeros at the end of the list
  inp.append(0)



output = inp


# Your code - end
print output
