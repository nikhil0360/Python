inp = "Plombez vingt fuyards!"
