set1 = {'abcdefgh', 'abcd', 'wxyz'}
set2 = {'ijklmnopqrstuvwxyz', 'abefgh'}
