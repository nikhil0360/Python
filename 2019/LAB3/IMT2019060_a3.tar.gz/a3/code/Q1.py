from Q1input import *

# Your code - begin
output ={}               #empty dictionary called 'output'
for i in inp:            #iterating i over the values of input
  if( i in output ):     #if 'i' is already a key in output
    output[i] += 1         #increate the value of that key by 1 (1++)
  else:                  #else 
    output[i] = 1          #create a key 'i' and set it's value as 1

# Your code - end

print(output)
