from Q5input import *

# Your code - begin
output = 0

sets = []
for i in set1:         
  for j in set2:
    sets.append(i+j)    #cartesian product of set1 and set2 and storing it in sets

print(sets)
for p in sets:
  if(len(p)==26):       #if length of 'p' in Sets is 26, then it CAN be a valid answer
    for n in p:         
      count = 0
      for m in p:
        if(n.lower()==m.lower()):  #comparing to see if every char in 'p' is unique
          count += 1
      if(count!=1):                #if every character is not unique , restart the outermost loop
        break                      #for further comparision
    else:
      output += 1



# Your code - end
print output
