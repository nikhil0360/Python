from Q1input import *

# Your code - begin
output=""
count = 0   # a counter that count no. of repeated letters 
a = inp[0]  # initial character 
for i in range(len(inp)): 
  if a==inp[i]:   # checking if the initial character 'a' is equal to forward 
                  # part of the string
    count += 1    # if it is increase the counter
  else:
    output+=a+str(count)   # else print the char+count 
    a=inp[i]               # chnage the character to the new character
    count=1              
output+=a+str(count)       # this part print the last part as there will be no 
                           # new character to excecute print statement through if/else
# Your code - end
print output
