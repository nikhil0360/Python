from Q3input import *

# Your code - begin
output = []
l1 = []
l2 = []
for n1,n2 in [(0,0) , (0,1) , (1,0) , (1,1)]:
  sum = 0
  for j in range(len(m2)):
    sum = sum + m1[n1][j]*m2[j][n2]
#   print sum 
  output.append(sum)
# Your code - end
print output
