from Q2input import *

# Your code - begin
# [{({})}]

input = [ '{' , '[' , '(' ]  # possible input brackets
out = [ '}' , ']' , ')' ]    # possible output brackets
bal = ['()' , '[]' , '{}' ]  # possible balanced brackets
stack = []                   # empty stack for performing check of parenthesis
for i in range(len(inp)):    
  a=inp[i]                   # storing one parenthesis in 'a'
  if(a in input):            # if 'a' is input type , add this in stack for later matching
    stack.insert(0,a)
  elif(a in out):            # if 'a' is output type , check conditions c1 and c2 
    if(len(stack)!=0 and (stack[0]+a in bal)):  # stack has atleast 1 element , and it has a input type
      stack.pop(0)                              #bracket , if both true pop the elements
    else:
      output = False                          # if c1 and c2 both not true, brackets are not proper 
if(len(stack)==0):                              
 output = True                                #finally checking if stack is not left with any brackets
else:
 output = False                               #if it is present, it means it didn't pop in checking .

   
  
  



# Your code - end
print output
