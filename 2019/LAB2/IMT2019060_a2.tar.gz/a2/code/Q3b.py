from Q3input import *

# Your code - begin
output = m1
m3 = []  #final transpose matrix will be m3
for i in range(len(m1[0])): 
  temp = []
  for j in range(len(m1)):
    temp.append(m1[j][i])  #main line : here using temp list we append in m3 element of required r and c
  m3.append(temp)

output = m3
# Your code - end
print output
