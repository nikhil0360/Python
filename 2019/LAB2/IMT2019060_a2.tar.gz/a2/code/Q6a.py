from Q6input import *

# Your code - begin
n = len(l)      # n is length to control no. of time loop runs
sum = 0         
count = 0       #count will iterate with every iteration
while(count<n):
  sum += l[count] # sum = sum + (new number from list)
  count += 1      # increment
output = sum/n    # average by diving sum by total 

# Your code - end
print output
