from Q4input import *

# Your code - begin
count = 0
output = []  
while(count<len(names)): #checking count less that list length
  a1 = names[count]      # storing values using 'count' as indices in 'a's 
  a2 = English[count]
  a3 = Maths[count]
  a4 = DS[count]
  a5 = Physics[count]
  count += 1 
  output.append((a1,a2,a3,a4,a5)) # appending a tuple in output list

# Your code - end
print output
