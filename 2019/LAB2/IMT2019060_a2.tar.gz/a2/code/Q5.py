from Q5input import *

# Your code - begin
#n = 2
#l = [1,2,3,4,5]
count = 0         
while(count<n):
  a = l.pop(0)  #poping the first element 
  l.append(a)   #appending the poped element in list / adding at last the poped element
  count += 1    
output = l 


# Your code - end
print output
