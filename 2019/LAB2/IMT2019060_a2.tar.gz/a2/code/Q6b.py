from Q6input import *

# Your code - begin
n = len(l)
l2 = [-99999999,99999999] # initialising a array with 2 extrmes to perform sorting
for i in range(n):        # we have to follow sorting process as many times as no. of elements
  a = l.pop(0)            # poping from start of list and storing in 'a' 
  for j in range(len(l2)):
    if(l2[j]<=a and l2[j+1]>=a):     # inserting 'a' where its value is middle of left and right values
      l2.insert(j+1,a)                 
      break               
l2.pop(0)                            # deleting the extreme -99999999
l2.pop(len(l2)-1)                    # deleting the extreme 99999999
if(n%2==0):
  output = l2[n/2] + l2[(n/2)+1]     # median for even
else:
  output = l2[(n+1)/2]               # median for odd

# Your code - end
print output
