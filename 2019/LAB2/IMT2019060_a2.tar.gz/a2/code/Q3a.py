from Q3input import *

# Your code - begin
output = m1

m3 = []                 
for i in range(len(m2[0])):  #here i will transpose the second matrix to simplfy the multiplication
  temp = []                  # transposing m2 into m3
  for j in range(len(m2)):
    temp.append(m2[j][i])
  m3.append(temp)

m4 = []                      #blanck list which will be product of matrices
temp2 = []                   #temporary list to make a row in the matrix
sum = 0
for m in range(len(m1)):
  for n in range(len(m3)):
    for o in range(len(m1[0])):
      sum += m1[m][o]*m3[n][o]  #matrix multiplication
    temp2.append(sum)           #temp list is made by appending the sum after multiplication
    sum = 0
  m4.append(temp2)              #temp is appended in final matrix m4 as a row
  temp2 = []                  

output = m4
# Your code - end
print output
