from Q7input import *

# Your code - begin
l1.insert(0,-99999999)       # adding extreme into l1 
l1.insert(len(l1),99999999)  # here l1 is sorted list
for i in range(len(l2)):     

  a = l2.pop(0)              # storing elements of l2 in 'a' using pop
  for j in range(len(l1)):   # l2 is unsorted loop
    if(l1[j]<a and l1[j+1]>a):  # insering 'a' in appropriate place
      l1.insert(j+1,a)      
l1.pop(0)                    # removing extremes
l1.pop(len(l1)-1)            

output = l1


# Your code - end
print output
