from Q6input import *

# Your code - begin
output = l

# Your code - end
print output
