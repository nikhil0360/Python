def print_n_message():     #defining a function
  i = 0                    # counter 'i' 
  while(i<10):             # using -while- loop for printing '10' times
    print("Hello world!")    # print 'hello world'
    i += 1                   #increase the counter 'i' by 1

