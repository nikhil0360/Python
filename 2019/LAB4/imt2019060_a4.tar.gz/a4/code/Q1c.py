def print_n_message(m):  #defining function
  i = 0                  #counter 'i'
  while(i<10):           #using -while- loop for printing '10' times
    print(m)               #print message 'm' - coustomised message
    i += 1                 #increasing counter 'i' by 1

