def diamond():            #defining function 'diamond'
  l1 = range(1,5//2+2)      # creating first part of list --> [1,2,3]
  l2 = range(5//2, 0,-1)    # creating second part of list --> [2,1]
  l3 = l1 + l2              # combing [1,2,3,2,1]
  i = 0                     # counter 'i'
  while(i<5):               # using -while- loop for printing the patter
    print(" "*((5//2)+1-l3[i]) + '*'*((2*l3[i])-1))  #using print and formulating for spaces ' '
    i += 1                                           # and '*' ( it's simple pattern observation)

#I am really happy with my code it's one of the shortest one can think.

'''
what i did is create a list of number like [1,2,3,2,1](for height = 5)
now using that list , i was easily able to create spaces and star as 
print(-space-*(n=5 - list_element[i]) + '*'*(some relation * list_item[i])
'''

  
