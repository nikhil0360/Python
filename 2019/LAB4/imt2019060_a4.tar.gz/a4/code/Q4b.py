def ndiamond(n):        #defining function diamond(n) , for height 'n' and number character
  l1 = range(1,n//2+2)     #first part of list --> [1,2,3,4,5.....floor(n/2)+1]
  l2 = range(n//2, 0,-1)   #second part of list --> [floor(n/2),floor(n/2)-1...... 3,2,1]
  l3 = l1 + l2             #[1,2,3,4......4,3,2,1]
  i = 0                    #counter 'i'

  while(i<n):              #using -while- loop for controling l3 items and no. of lines printed
    a = '1'*l3[i]          # a is a string with '1','11'..'1*l3[i]' as per the l3 items and 'i'
    print(" "*((n//2)+1-l3[i]) + str(int(a)**2))  #printing spaces and 'a'^2
    i += 1                                        #increasing counter by '1'



