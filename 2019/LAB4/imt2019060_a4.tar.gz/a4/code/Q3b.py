def diamond(n):          #defining function diamond(n) , for height 'n'
  l1 = range(1,n//2+2)     #first part of list --> [1,2,3,4,5.....floor(n/2)+1]
  l2 = range(n//2, 0,-1)   #second part of list --> [floor(n/2),floor(n/2)-1...... 3,2,1]
  l3 = l1 + l2             #[1,2,3,4......4,3,2,1]
  i = 0                    #counter 'i'
  while(i<n):              #using -while- loop for controling l3 items and number of lines print
    print(" "*((n//2)+1-l3[i]) + '*'*((2*l3[i])-1))  #print patern line-by-line
    i += 1                                           #increasing counter 'i' by 1


