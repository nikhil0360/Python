def print_n_message(n):    #defining function
  i = 0                    #counter 'i'
  while(i<n):              #using -while- loop for printing 'n' times
    print("Hello world!")    #print hello world
    i += 1                   #increasing counter 'i' by 1

