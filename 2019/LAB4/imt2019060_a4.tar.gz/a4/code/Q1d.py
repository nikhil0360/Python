def print_n_message(m,n):  #defining function
  i = 0                    # counter 'i'
  while(i<n):              # using -while- loop for printing message 'm' , 'n' times
    print(m)                 #printing message 'm' 
    i += 1                   #increasing counter by '1'

