def banner(m):            #defining function 'banner' which print message 'm'
  n = len(m)+4            # 'n' = message length + 4 ( 2 space + 2 star )
  print('*'*n)            # printing upper star line
  print('* '+ m + ' *')   # printing message line
  print('*'*n)            # printing lower star line


